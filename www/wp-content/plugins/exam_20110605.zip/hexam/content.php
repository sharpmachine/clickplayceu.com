<?php
$word["hsubmit"]="Finish";
$word["hscore_1"]="Your score is";
$word["hscore_2"]="points";
$word["hrec"]="Your results has been received";
$word["hbut"]="But we can not accept your result because of you did this test before";
$word["hlogin"]="You must be logged in to participate in this test";
$word["hcongrat"]="Congratulations! You've passed!";
$word["hbest"]="You've scored a personal best for this test but have not met the minimum score of 70%. Please try again.";
?>